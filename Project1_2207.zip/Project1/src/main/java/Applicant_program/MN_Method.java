package Applicant_program;

public class MN_Method {
    
	public static void main(String[] args) {
		
		MN_Start mns = new MN_Start();
		mns.mnStart();
		
		MN_Menu mnm = new MN_Menu();
		mnm.mnMenu();
		
		}
		
	}	
		
	


		
	

	