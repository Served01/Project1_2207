package Applicant_program;

public class MN_Start {

	public void mnStart() {
		
		System.out.println();
		System.out.println("=====면접 합격 확인 프로그램=====");
		System.out.println();
	
		DB_Connection.getConn();
		
	}
}
